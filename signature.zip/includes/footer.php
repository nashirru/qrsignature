<?php
// includes/footer.php
?>
            </div>
        </main>
    </div>
    <script src="assets/script.js"></script>
</body>
</html>