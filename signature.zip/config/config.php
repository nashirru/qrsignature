<?php
// Direktori: /signature/config/
// Nama File: config.php
// Path Lengkap: /signature/config/config.php

// Konfigurasi koneksi database
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // Ganti dengan username database Anda
define('DB_PASS', '');     // Ganti dengan password database Anda
define('DB_NAME', 'qr'); // Ganti dengan nama database Anda

// URL dasar aplikasi Anda (PENTING: Sudah diubah sesuai nama folder baru)
// Ganti http://localhost/signature/ jika path Anda berbeda
define('BASE_URL', 'http://localhost/signature/');
?>